@component('mail::message')
# Student Enrollment Confirmation

Dear {{ $parent->first_name }} {{ $parent->last_name }},

We are pleased to confirm that your child has been successfully enrolled at {{ config('app.name') }}.

## Enrollment Details

@component('mail::table')
| Information | Details |
|---|---|
| **Student Name** | {{ $student->first_name }} {{ $student->last_name }} |
| **Admission Number** | {{ $admissionNumber }} |
| **Date of Birth** | {{ $student->date_of_birth?->format('d M Y') ?? 'Not Provided' }} |
| **Class** | {{ $student->schoolClass?->name ?? 'To be assigned' }} |
| **Enrollment Date** | {{ now()->format('d M Y') }} |
@endcomponent

## What's Next?

1. **Portal Access**: You now have access to the Parent Portal where you can:
   - View student progress and attendance
   - Monitor grades and performance
   - Receive school communications
   - Manage bills and payments

2. **Important Documents**: Please ensure you provide:
   - Birth certificate or national ID
   - Medical records and vaccination proof
   - Previous school records (if transferring)

3. **School Handbook**: Review the school handbook for policies regarding:
   - School hours and holidays
   - Dress code
   - Code of conduct
   - Fees and payment terms

4. **Fee Structure**: Bills for the current academic session will be generated shortly. You can view and pay bills through the Parent Portal.

## School Information

- **Address**: [School Address]
- **Phone**: [School Phone]
- **Email**: {{ config('mail.from.address') }}
- **Portal**: [Parent Portal URL]

@component('mail::button', ['url' => route('parent-portal.index')])
Access Parent Portal
@endcomponent

If you have any questions regarding your child's enrollment or need any assistance, please do not hesitate to contact us.

We look forward to supporting your child's educational journey at {{ config('app.name') }}.

Best regards,  
**School Administration**  
{{ config('app.name') }}
@endcomponent
