@component('mail::message')
# New Bill(s) Created

Dear {{ $parent->first_name }} {{ $parent->last_name }},

We are writing to inform you that a new bill has been created for your child/children at {{ config('app.name') }}.

## Summary

@component('mail::table')
| Student Name | Admission Number | Class | Amount | Due Date |
|---|---|---|---|---|
@forelse($bills as $bill)
| {{ $bill->student->first_name }} {{ $bill->student->last_name }} | {{ $bill->student->admission_number }} | {{ $bill->student->schoolClass?->name ?? 'N/A' }} | ₦{{ number_format($bill->total_amount, 2) }} | {{ $bill->due_date?->format('M d, Y') ?? 'Not Set' }} |
@empty
| No bills | - | - | - | - |
@endforelse
@endcomponent

**Total Outstanding Amount:** ₦{{ number_format($totalAmount, 2) }}

**Number of Children with Bills:** {{ $childrenCount }}

## Next Steps

Please log in to your parent portal to:
- View detailed bill information
- Make payments online
- Download bill receipts
- Set up payment reminders

@component('mail::button', ['url' => route('parent-portal.index')])
View Your Bills
@endcomponent

If you have any questions regarding these bills, please contact us at {{ config('school.contact_email', config('mail.from.address')) }}.

Thank you for your attention.

Best regards,  
{{ config('app.name') }} - Finance Department
@endcomponent
