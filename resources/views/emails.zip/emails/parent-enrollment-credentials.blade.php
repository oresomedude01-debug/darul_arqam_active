@component('mail::message')
# Welcome to {{ $appName }}

Hello {{ $parentName }},

Your child **{{ $studentName }}** has been successfully enrolled in {{ $appName }}!

## Your Parent Portal Account

An account has been created for you so you can manage your child's education and stay connected with the school.

### Login Credentials

**Email:** `{{ $parentEmail }}`  
**Temporary Password:** `{{ $defaultPassword }}`

---

## Important Instructions

1. **First Login:** Go to [{{ config('app.url') }}]({{ $loginUrl }}) and sign in with the credentials above
2. **Change Your Password:** After your first login, you **MUST** change your password immediately for security
3. **Create a Strong Password:** Use a combination of uppercase, lowercase, numbers, and special characters
4. **Keep it Safe:** Never share your login credentials with anyone

---

## What You Can Do

Once logged in, you can:
- ✅ View your child's academic progress
- ✅ Check attendance records
- ✅ View grades and reports
- ✅ Communicate with teachers
- ✅ Pay school fees online
- ✅ Update your profile information

---

## Need Help?

If you have any questions or issues logging in, please contact the school:

📧 **Email:** {{ config('app.school_email', 'info@school.com') }}  
📞 **Phone:** {{ config('app.school_phone', '+1-000-000-0000') }}

---

Best regards,  
**{{ $appName }} Administration**

@endcomponent
