@component('mail::message')
# Welcome to {{ config('app.name') }}

Dear {{ $teacher->first_name }} {{ $teacher->last_name }},

Welcome to {{ config('app.name') }}! We are delighted to have you join our educational team.

## Your Account Information

Your teacher account has been created successfully. Please use the following credentials to access the school management system:

@component('mail::table')
| Field | Details |
|---|---|
| **Email** | {{ $teacher->email }} |
| **Temporary Password** | {{ $temporaryPassword }} |
| **School** | {{ config('app.name') }} |
@endcomponent

## Important Next Steps

1. **Login to Your Dashboard**: Visit the school portal and log in with your email and the temporary password provided above.

2. **Change Your Password**: For security purposes, you will be prompted to change your password on first login.

3. **Complete Your Profile**: Please update your profile information including contact details and professional qualifications.

4. **Review School Policies**: Familiarize yourself with school policies, timetables, and procedures in the Staff Handbook section.

## Your Role & Responsibilities

As a member of our teaching staff, you have access to:
- **Class Management**: Manage student attendance, grades, and performance
- **Communication**: Send messages to parents and students
- **Reports**: Generate student performance reports
- **Calendar**: View and manage academic events and holidays

## Need Help?

If you have any difficulty accessing your account or need technical assistance, please contact our IT support team at {{ config('mail.from.address') }}.

@component('mail::button', ['url' => url('/login')])
Log In to Your Account
@endcomponent

We look forward to working with you and wish you a fulfilling career at {{ config('app.name') }}.

Best regards,  
**School Administration**  
{{ config('app.name') }}
@endcomponent
