@component('mail::message')
# Payment Reminder - Outstanding Bills

Dear {{ $parent->first_name }} {{ $parent->last_name }},

This is a friendly reminder that there are outstanding bills pending payment for your child/children at {{ config('app.name') }}.

## Outstanding Bills Summary

@component('mail::table')
| Student Name | Admission Number | Class | Balance Due | Due Date |
|---|---|---|---|---|
@forelse($bills as $bill)
| {{ $bill->student->first_name }} {{ $bill->student->last_name }} | {{ $bill->student->admission_number }} | {{ $bill->student->schoolClass?->name ?? 'N/A' }} | ₦{{ number_format($bill->balance_due, 2) }} | {{ $bill->due_date?->format('M d, Y') ?? 'Not Set' }} |
@empty
| No outstanding bills | - | - | - | - |
@endforelse
@endcomponent

**Total Amount Due:** ₦{{ number_format($totalDue, 2) }}

## Payment Options

You can make payments through:
- Online payment gateway (Paystack, etc.)
- Bank transfer
- Cash payment at school office
- Cheque payment

## Take Action Now

@component('mail::button', ['url' => route('parent-portal.index')])
Pay Your Bills Online
@endcomponent

## Need Help?

If you have questions about your bills or need assistance with payment, please contact our finance department at {{ config('school.contact_email', config('mail.from.address')) }}.

We appreciate your prompt attention to this matter.

Best regards,  
{{ config('app.name') }} - Finance Department
@endcomponent
